package com.deloitte.pms.client;


public class Client {

	public static void main(String[] args) {

		LaunchApp.startCustomerApp();
	}
}
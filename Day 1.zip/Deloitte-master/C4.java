public class C4 {
public void sayWelcome() {
		
		System.out.println("Welcome in C4");

	}

}

//change i access to see effect on other classes/packages
//           A B C D E
//public     . . . . .
//private    . * * * *
//default    . . . * *
//protected  . . . * .
// . works
// * doesn't works


package pack1;

public class A {
	public int i;

}

public class C1 {
public void sayWelcome() {
		
		System.out.println("Welcome in C1");

	}

}

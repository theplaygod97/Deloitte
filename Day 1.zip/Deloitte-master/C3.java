public class C3 {
public void sayWelcome() {
		
		System.out.println("Welcome in C3");

	}
}

public class C2 {
public void sayWelcome() {
		
		System.out.println("Welcome in C2");

	}

}

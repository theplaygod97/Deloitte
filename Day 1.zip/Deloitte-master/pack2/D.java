package pack2;

import pack1.A;

public class D {
	public void display() {
		A a = new A();
		a.i=100;
	}
}
